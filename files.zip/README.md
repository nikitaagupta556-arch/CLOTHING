# FitMap

Enter your measurements once. FitMap checks them against each brand's size chart,
shows a 3D dress form that matches your body, and lets you preview a garment on your own photo.

Static site: plain HTML, CSS and JavaScript. No build step, no dependencies to install.
Three.js loads from a CDN (jsDelivr, pinned to 0.160.0), so you need an internet connection.

## Files

| File | Purpose |
| --- | --- |
| `index.html` | Page structure |
| `styles.css` | All styling |
| `js/main.js` | State, sliders, brand rows, cart |
| `js/fit.js` | Size recommendation logic |
| `js/data.js` | Brand size charts (SAMPLE data, replace with official charts) |
| `js/body3d.js` | Three.js dress form |
| `js/tryon.js` | Photo upload and garment overlay |
| `vercel.json` | Headers and clean URLs for Vercel |
| `test/fit.test.js` | Checks the sizing logic: `npm test` |

## Run locally

ES modules do not load from `file://`, so serve the folder:

    npx serve .

then open the printed address.

## Deploy to Vercel

Option A, command line:

    npm i -g vercel
    cd fitmap
    vercel          # preview
    vercel --prod   # production

When asked, accept the defaults. There is no build command and the output directory is `.`.

Option B, Git:

1. Push this folder to a GitHub repository.
2. In Vercel choose Add New, then Project, and import the repository.
3. Framework preset: Other. Leave build command empty. Deploy.

## Before you rely on it

- `js/data.js` holds illustrative ranges, not official ones. Edit `start`, `step`,
  `drop` and `hip` per brand (explained at the top of that file).
- The try-on is an overlay preview. It does not simulate fabric. A realistic try-on
  needs an AI model behind a serverless function (add an `api/` folder on Vercel).
- Photos never leave the browser.
