import * as THREE from 'three';

const S = 0.02;            // 1 cm = 0.02 scene units
const TAU = Math.PI * 2;
const KEYS = ['height', 'chest', 'waist', 'hips'];
const ease = (t) => 1 - Math.pow(1 - t, 3);

export function initBody(canvas) {
  const host = canvas.parentElement;
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
  const target = new THREE.Vector3(0, 1.75, 0);

  // lighting stays fixed relative to the camera; the model turns instead
  scene.add(new THREE.HemisphereLight(0xdfe6ff, 0x101a3a, 1.15));
  const key = new THREE.DirectionalLight(0xfff0d8, 2.5);
  key.position.set(4, 6, 6);
  const rim = new THREE.DirectionalLight(0x7f9bff, 2.2);
  rim.position.set(-6, 3, -4);
  scene.add(key, rim);

  const linen = new THREE.MeshStandardMaterial({ color: 0xe9e4d8, roughness: 0.62, metalness: 0.02 });
  const tapeMat = new THREE.MeshBasicMaterial({ color: 0xffc93c });
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x16275a, roughness: 0.7 });

  const turn = new THREE.Group();   // everything that spins
  const body = new THREE.Group();   // rebuilt on measurement change
  turn.add(body);
  scene.add(turn);

  // turntable with centimetre ticks
  const base = new THREE.Mesh(new THREE.CylinderGeometry(2.7, 2.7, 0.05, 96), baseMat);
  base.position.y = -0.03;
  turn.add(base);
  const TICKS = 150;
  const ticks = new THREE.InstancedMesh(new THREE.BoxGeometry(0.014, 0.012, 0.1), tapeMat, TICKS);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < TICKS; i++) {
    const a = (i / TICKS) * TAU;
    const major = i % 5 === 0;
    dummy.position.set(Math.cos(a) * 2.5, 0.0, Math.sin(a) * 2.5);
    dummy.rotation.set(0, -a, 0);
    dummy.scale.set(1, 1, major ? 1.9 : 1);
    dummy.updateMatrix();
    ticks.setMatrixAt(i, dummy.matrix);
  }
  turn.add(ticks);

  function clear() {
    for (const c of [...body.children]) {
      body.remove(c);
      c.geometry.dispose();
    }
  }

  function build(m) {
    clear();
    const H = m.height * S;
    const r = (c) => (c / TAU) * S;
    const rC = r(m.chest);
    const rW = r(m.waist);
    const rH = r(m.hips);

    // torso profile, smoothed
    const raw = [
      [0.001, 0.47], [rH * 0.8, 0.485], [rH, 0.525], [(rH + rW) / 2, 0.58],
      [rW, 0.63], [(rW + rC) / 2, 0.685], [rC, 0.735], [rC * 0.93, 0.78],
      [Math.max(rC * 0.62, H * 0.06), 0.815], [H * 0.05, 0.835], [0.001, 0.845],
    ].map(([x, y]) => new THREE.Vector2(x, y * H));
    const pts = new THREE.SplineCurve(raw).getPoints(70).map((p) => new THREE.Vector2(Math.max(0.001, p.x), p.y));
    const torso = new THREE.Mesh(new THREE.LatheGeometry(pts, 56), linen);
    torso.scale.set(1.18, 1, 0.82);
    body.add(torso);

    // neck + head
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(H * 0.04, H * 0.046, H * 0.06, 20), linen);
    neck.position.y = H * 0.85;
    const head = new THREE.Mesh(new THREE.SphereGeometry(H * 0.062, 32, 24), linen);
    head.scale.set(0.88, 1.12, 0.95);
    head.position.y = H * 0.92;
    body.add(neck, head);

    // legs + feet
    for (const side of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(rH * 0.56, rH * 0.2, H * 0.47, 28), linen);
      leg.position.set(side * rH * 0.58, H * 0.235, 0);
      const foot = new THREE.Mesh(new THREE.SphereGeometry(H * 0.036, 16, 12), linen);
      foot.scale.set(1, 0.5, 1.9);
      foot.position.set(side * rH * 0.58, H * 0.018, H * 0.03);
      body.add(leg, foot);
    }

    // shoulders, arms, hands
    for (const side of [-1, 1]) {
      const sx = side * (rC * 1.1 + H * 0.005);
      const shoulder = new THREE.Mesh(new THREE.SphereGeometry(H * 0.048, 20, 16), linen);
      shoulder.position.set(sx, H * 0.775, 0);
      const ax = side * (rC * 1.1 + H * 0.02);
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(H * 0.034, H * 0.024, H * 0.34, 18), linen);
      arm.position.set(ax, H * 0.605, 0);
      arm.rotation.z = side * 0.07;
      const hand = new THREE.Mesh(new THREE.SphereGeometry(H * 0.028, 14, 12), linen);
      hand.position.set(ax + side * H * 0.17 * 0.07, H * 0.605 - H * 0.17 - H * 0.01, 0);
      body.add(shoulder, arm, hand);
    }

    // measuring rings: where chest, waist and hips are taken
    const ringAt = (radius, yFrac) => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(radius + 0.012, 0.014, 12, 90), tapeMat);
      ring.rotation.x = Math.PI / 2;
      ring.scale.set(1.18, 0.82, 1);
      ring.position.y = yFrac * H;
      body.add(ring);
    };
    ringAt(rC, 0.735);
    ringAt(rW, 0.63);
    ringAt(rH, 0.525);
  }

  // measurement tween
  const cur = { height: 175, chest: 98, waist: 84, hips: 98 };
  const goal = { ...cur };
  let settled = false;
  build(cur);

  function set(m) {
    for (const k of KEYS) goal[k] = m[k];
    settled = false;
  }

  // drag to turn, with inertia and idle spin
  let angle = 0.5;
  let vel = 0;
  let dragging = false;
  let lastX = 0;
  let lastInput = -10;
  canvas.addEventListener('pointerdown', (e) => {
    dragging = true; lastX = e.clientX; vel = 0;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const dx = e.clientX - lastX;
    lastX = e.clientX;
    angle += dx * 0.011;
    vel = dx * 0.011;
  });
  const end = () => { dragging = false; lastInput = clock.getElapsedTime(); };
  canvas.addEventListener('pointerup', end);
  canvas.addEventListener('pointercancel', end);

  function resize() {
    const w = host.clientWidth;
    const h = host.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    const dist = camera.aspect < 0.85 ? 12.4 : camera.aspect < 1.1 ? 10.6 : 9.4;
    camera.position.set(0, 2.5, dist);
    camera.lookAt(target);
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(host);
  resize();

  const clock = new THREE.Clock();
  let intro = reduce ? 1 : 0;

  function frame() {
    const dt = Math.min(clock.getDelta(), 0.05);
    const t = clock.getElapsedTime();

    if (!settled) {
      let moving = false;
      for (const k of KEYS) {
        const d = goal[k] - cur[k];
        if (Math.abs(d) > 0.02) { cur[k] += d * Math.min(1, dt * 10); moving = true; }
        else cur[k] = goal[k];
      }
      build(cur);
      if (!moving) settled = true;
    }

    if (!dragging) {
      angle += vel;
      vel *= 0.94;
      if (!reduce && t - lastInput > 1.5) angle += dt * 0.35;
    }

    // one page-load moment: the form spins in and rises to full height
    if (intro < 1) intro = Math.min(1, intro + dt / 1.5);
    const e = ease(intro);
    turn.rotation.y = angle + (1 - e) * Math.PI * 1.6;
    turn.scale.setScalar(0.88 + 0.12 * e);
    turn.position.y = (1 - e) * -0.6;

    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  return { set };
}
