// SAMPLE DATA. These ranges are illustrative, not official.
// Replace with each brand's real size guide before relying on results.
//
// Each category is generated from a few numbers:
//   labels: size names, smallest to largest
//   start:  lowest body measurement (cm) covered by the first size
//   step:   cm covered by each size
//   tops:    chest = start + i*step, waist = chest - drop
//   bottoms: waist = start + i*step, hips  = waist + hip

const LETTERS = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const WAIST_IN = ['28', '30', '32', '34', '36', '38'];

export const BRANDS = [
  {
    id: 'zara', name: 'Zara', fit: 'Slim cut. Most people size up.',
    tops: { labels: LETTERS, start: 79, step: 6, drop: 12 },
    bottoms: { labels: WAIST_IN, start: 68, step: 5, hip: 14 },
  },
  {
    id: 'hm', name: 'H&M', fit: 'Regular fit. Close to a standard chart.',
    tops: { labels: LETTERS, start: 82, step: 6, drop: 12 },
    bottoms: { labels: WAIST_IN, start: 70, step: 5, hip: 14 },
  },
  {
    id: 'uniqlo', name: 'Uniqlo', fit: 'Compact cut. Sizes run small.',
    tops: { labels: LETTERS, start: 76, step: 6, drop: 12 },
    bottoms: { labels: LETTERS, start: 62, step: 6, hip: 14 },
  },
  {
    id: 'roadster', name: 'Roadster (Myntra)', fit: 'Generous cut. Sizes run large.',
    tops: { labels: LETTERS, start: 87, step: 6, drop: 12 },
    bottoms: { labels: ['30', '32', '34', '36', '38', '40'], start: 72, step: 5, hip: 14 },
  },
  {
    id: 'bewakoof', name: 'Bewakoof', fit: 'Oversized. Size down from your usual.',
    tops: { labels: ['S', 'M', 'L', 'XL', 'XXL', '3XL'], start: 94, step: 8, drop: 14 },
    bottoms: { labels: ['S', 'M', 'L', 'XL', 'XXL', '3XL'], start: 70, step: 8, hip: 18 },
  },
  {
    id: 'levis', name: "Levi's", fit: 'Straight cut. Roughly true to size.',
    tops: { labels: LETTERS, start: 85, step: 6, drop: 12 },
    bottoms: { labels: WAIST_IN, start: 71, step: 5, hip: 14 },
  },
];

export const CHIP_BRANDS = ['zara', 'hm', 'roadster', 'bewakoof'];
