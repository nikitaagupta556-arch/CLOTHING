// Size recommendation engine. No dependencies, runs in browser or Node.

const WEIGHTS = {
  tops: { chest: 1, waist: 0.5 },
  bottoms: { waist: 1, hips: 0.6 },
};

export const PRIMARY = { tops: 'chest', bottoms: 'waist' };
export const AXIS = { tops: [75, 130], bottoms: [60, 110] };

export function buildChart(brand, cat) {
  const t = brand[cat];
  return t.labels.map((label, i) => {
    const lo = t.start + i * t.step;
    const hi = lo + t.step;
    const ranges = cat === 'tops'
      ? { chest: [lo, hi], waist: [lo - t.drop, hi - t.drop] }
      : { waist: [lo, hi], hips: [lo + t.hip, hi + t.hip] };
    return { label, ranges };
  });
}

export function recommend(brand, cat, m) {
  const chart = buildChart(brand, cat);
  const w = WEIGHTS[cat];
  const primary = PRIMARY[cat];

  const scored = chart.map((s, i) => {
    let dev = 0;
    let mid = 0;
    for (const k of Object.keys(w)) {
      const [lo, hi] = s.ranges[k];
      const v = m[k];
      dev += w[k] * (v < lo ? lo - v : v > hi ? v - hi : 0);
      mid += w[k] * Math.abs(v - (lo + hi) / 2);
    }
    return { i, dev, mid, s };
  }).sort((a, b) => a.dev - b.dev || a.mid - b.mid);

  const best = scored[0];
  const size = best.s;
  const score = Math.max(0, Math.round(100 - best.dev * 9 - best.mid * 0.8));
  const [lo, hi] = size.ranges[primary];
  const v = m[primary];
  const prev = chart[best.i - 1];
  const next = chart[best.i + 1];
  const first = chart[0].ranges[primary][0];
  const last = chart[chart.length - 1].ranges[primary][1];

  let tag;
  let tip;
  if (v < first - 2 || v > last + 2) {
    tag = 'Outside this chart';
    tip = 'Your measurement is beyond this brand\u2019s range, so treat this as the nearest size.';
  } else if (best.dev === 0) {
    tag = 'Within range';
    if (v - lo <= 1.2 && prev) tip = `Near the low end. ${prev.label} would fit closer.`;
    else if (hi - v <= 1.2 && next) tip = `Near the top end. ${next.label} would fit looser.`;
    else tip = 'Sits comfortably inside this size.';
  } else {
    tag = 'Between sizes';
    tip = `${scored[1].s.label} is the next closest.`;
  }

  return { size: size.label, ranges: size.ranges, score, tag, tip, chart, index: best.i };
}
