import assert from 'node:assert/strict';
import { BRANDS } from '../js/data.js';
import { recommend, buildChart } from '../js/fit.js';

const m = { height: 175, chest: 98, waist: 84, hips: 98 };
const size = (id, cat, meas = m) => recommend(BRANDS.find((b) => b.id === id), cat, meas).size;

// same body, different brands, different sizes
assert.equal(size('zara', 'tops'), 'L');
assert.equal(size('hm', 'tops'), 'M');
assert.equal(size('bewakoof', 'tops'), 'S');
assert.equal(size('roadster', 'tops'), 'S');

// every brand returns a size that exists in its own chart
for (const b of BRANDS) for (const cat of ['tops', 'bottoms']) {
  const r = recommend(b, cat, m);
  assert.ok(buildChart(b, cat).some((s) => s.label === r.size), `${b.id} ${cat}`);
  assert.ok(r.score >= 0 && r.score <= 100);
}

// extremes stay inside the chart and are flagged
const huge = recommend(BRANDS[0], 'tops', { height: 190, chest: 130, waist: 120, hips: 128 });
assert.equal(huge.size, 'XXL');
assert.equal(huge.tag, 'Outside this chart');
const tiny = recommend(BRANDS[0], 'tops', { height: 155, chest: 70, waist: 58, hips: 80 });
assert.equal(tiny.size, 'XS');

console.log('fit tests passed');
