import { BRANDS, CHIP_BRANDS } from './data.js';
import { recommend, PRIMARY, AXIS } from './fit.js';
import { initBody } from './body3d.js';
import { initTryOn } from './tryon.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const cap = (s) => s[0].toUpperCase() + s.slice(1);
const KEY = 'fitmap:v1';

const state = { m: { height: 175, chest: 98, waist: 84, hips: 98 }, cat: 'tops', cart: [] };

// restore saved measurements
try {
  const saved = JSON.parse(localStorage.getItem(KEY) || 'null');
  if (saved && saved.m) Object.assign(state.m, saved.m);
  if (saved && (saved.cat === 'tops' || saved.cat === 'bottoms')) state.cat = saved.cat;
} catch { /* storage unavailable, use defaults */ }
const save = () => {
  try { localStorage.setItem(KEY, JSON.stringify({ m: state.m, cat: state.cat })); } catch { /* ignore */ }
};

// 3D form
let body = null;
try {
  body = initBody($('#body'));
} catch (err) {
  console.warn('3D unavailable:', err);
  $('.hero-3d').classList.add('no3d');
}

// measurement controls
function syncInputs() {
  $$('input[data-k]').forEach((el) => {
    const k = el.dataset.k;
    el.value = state.m[k];
    state.m[k] = +el.value; // clamp to slider limits
    $(`[data-out="${k}"]`).textContent = state.m[k];
    $(`[data-in="${k}"]`).textContent = `(${(state.m[k] / 2.54).toFixed(1)} in)`;
  });
}

$$('input[data-k]').forEach((el) => {
  el.addEventListener('input', () => {
    const k = el.dataset.k;
    state.m[k] = +el.value;
    $(`[data-out="${k}"]`).textContent = state.m[k];
    $(`[data-in="${k}"]`).textContent = `(${(state.m[k] / 2.54).toFixed(1)} in)`;
    update();
  });
});

// hero chips
function renderChips() {
  $('#chips').innerHTML = CHIP_BRANDS.map((id) => {
    const br = BRANDS.find((b) => b.id === id);
    const r = recommend(br, state.cat, state.m);
    return `<li class="chip">${br.name.replace(' (Myntra)', '')}<b>${r.size}</b></li>`;
  }).join('');
}

// brand rows
function renderRows() {
  const cat = state.cat;
  const key = PRIMARY[cat];
  const [a, b] = AXIS[cat];
  const pct = (v) => ((Math.min(b, Math.max(a, v)) - a) / (b - a)) * 100;

  $('#rows').innerHTML = BRANDS.map((br) => {
    const r = recommend(br, cat, state.m);
    const segs = r.chart.map((s) => {
      const [lo, hi] = s.ranges[key];
      const l = pct(lo);
      return `<span class="seg${s.label === r.size ? ' on' : ''}" style="left:${l}%;width:${pct(hi) - l}%"><b>${s.label}</b></span>`;
    }).join('');
    const detail = Object.entries(r.ranges).map(([k, [lo, hi]]) => `${cap(k)} ${lo}\u2013${hi} cm`).join(', ');
    return `
      <article class="row">
        <div>
          <h3>${br.name}</h3>
          <p class="fit">${br.fit}</p>
        </div>
        <div>
          <div class="tape" style="--n:${b - a}" role="img" aria-label="${br.name} ${cat} chart by ${key}. You are ${state.m[key]} cm. Recommended size ${r.size}.">
            ${segs}
            <i class="you" style="left:${pct(state.m[key])}%"><u>${state.m[key]} cm</u></i>
          </div>
          <p class="cap">Size ${r.size} covers ${detail}</p>
          <p class="tip">${r.tag}. ${r.tip}</p>
        </div>
        <div class="pick">
          <b>${r.size}</b>
          <span>${r.score}% match</span>
          <button class="btn" type="button" data-add="${br.id}">Add to cart</button>
        </div>
      </article>`;
  }).join('');
}

$('#rows').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-add]');
  if (!btn) return;
  const br = BRANDS.find((x) => x.id === btn.dataset.add);
  const r = recommend(br, state.cat, state.m);
  addToCart({ brandId: br.id, cat: state.cat, size: r.size, color: null, photo: null });
});

// category toggles (shared by both sections)
function setCat(cat) {
  state.cat = cat;
  $$('.toggle [data-cat]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.cat === cat)));
  update();
}
$$('.toggle [data-cat]').forEach((b) => b.addEventListener('click', () => setCat(b.dataset.cat)));

// cart
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

function renderCart() {
  $('#cartCount').textContent = state.cart.length;
  const list = $('#cartList');
  if (!state.cart.length) {
    list.innerHTML = '<li class="cart-empty">Your cart is empty. Add a size from any brand.</li>';
    return;
  }
  list.innerHTML = state.cart.map((it, i) => {
    const br = BRANDS.find((b) => b.id === it.brandId);
    const bg = it.photo ? `background-image:url('${it.photo}')` : '';
    const dot = it.color ? `style="--c:${it.color}"` : 'style="display:none"';
    return `
      <li>
        <div class="thumb" style="${bg}"><i ${dot}></i></div>
        <div><b>${br.name}</b><small>${it.cat === 'tops' ? 'Top' : 'Bottom'}, size ${it.size}</small></div>
        <button type="button" data-rm="${i}">Remove</button>
      </li>`;
  }).join('');
}

function addToCart(item) {
  state.cart.push(item);
  renderCart();
  const br = BRANDS.find((b) => b.id === item.brandId);
  toast(`Added ${br.name} size ${item.size} to your cart`);
}

$('#cartList').addEventListener('click', (e) => {
  const b = e.target.closest('[data-rm]');
  if (!b) return;
  state.cart.splice(+b.dataset.rm, 1);
  renderCart();
});

const cartEl = $('#cart');
function openCart(open) {
  cartEl.classList.toggle('open', open);
  cartEl.setAttribute('aria-hidden', String(!open));
  $('#cartBtn').setAttribute('aria-expanded', String(open));
  if (open) $('#cartClose').focus();
}
$('#cartBtn').addEventListener('click', () => openCart(!cartEl.classList.contains('open')));
$('#cartClose').addEventListener('click', () => { openCart(false); $('#cartBtn').focus(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && cartEl.classList.contains('open')) openCart(false); });

// try-on
const tryon = initTryOn({ state, onAdd: addToCart });

function update() {
  if (body) body.set(state.m);
  renderChips();
  renderRows();
  tryon.refresh();
  save();
}

syncInputs();
setCat(state.cat);
renderCart();
