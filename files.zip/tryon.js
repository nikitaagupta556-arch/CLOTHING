import { BRANDS } from './data.js';
import { recommend } from './fit.js';

const TEE = 'M70 20 L38 36 L8 78 L40 100 L56 84 L56 188 L144 188 L144 84 L160 100 L192 78 L162 36 L130 20 C122 40 78 40 70 20Z';
const PANTS = 'M52 8 H148 L158 192 H110 L100 78 L90 192 H42 Z';
const COLORS = [
  ['Chalk', '#F5F1E6'], ['Black', '#1B1B1F'], ['Blue', '#2F5BFF'],
  ['Red', '#FF5B4A'], ['Green', '#3E7C59'], ['Sand', '#C9A66B'],
];
const START = { tops: { x: 50, y: 40 }, bottoms: { x: 50, y: 68 } };

const $ = (s) => document.querySelector(s);

export function initTryOn({ state, onAdd }) {
  const stage = $('#stage');
  const photo = $('#photo');
  const garment = $('#garment');
  const path = $('#garmentPath');
  const tag = $('#stageTag');
  const sel = $('#brandSel');
  const file = $('#file');
  const fileMsg = $('#fileMsg');
  const scale = $('#scale');
  const swatches = $('#swatches');

  let color = COLORS[0][1];
  let photoUrl = null;
  let pos = { ...START[state.cat] };
  let lastCat = state.cat;

  sel.innerHTML = BRANDS.map((b) => `<option value="${b.id}">${b.name}</option>`).join('');

  swatches.innerHTML = COLORS.map(([name, hex], i) =>
    `<button type="button" class="swatch" data-hex="${hex}" aria-label="${name}" aria-pressed="${i === 0}" style="background:${hex}"></button>`).join('');
  swatches.addEventListener('click', (e) => {
    const b = e.target.closest('.swatch');
    if (!b) return;
    color = b.dataset.hex;
    swatches.querySelectorAll('.swatch').forEach((s) => s.setAttribute('aria-pressed', String(s === b)));
    garment.style.setProperty('--g', color);
  });

  function place() {
    garment.style.left = pos.x + '%';
    garment.style.top = pos.y + '%';
  }

  function refresh() {
    if (state.cat !== lastCat) { pos = { ...START[state.cat] }; lastCat = state.cat; }
    path.setAttribute('d', state.cat === 'tops' ? TEE : PANTS);
    garment.style.setProperty('--g', color);
    const brand = BRANDS.find((b) => b.id === sel.value) || BRANDS[0];
    const rec = recommend(brand, state.cat, state.m);
    tag.textContent = `${brand.name}: size ${rec.size}`;
    place();
  }

  sel.addEventListener('change', refresh);
  scale.addEventListener('input', () => { garment.style.width = scale.value + '%'; });

  // drag the garment
  let drag = null;
  garment.addEventListener('pointerdown', (e) => {
    const r = stage.getBoundingClientRect();
    drag = { r, sx: e.clientX, sy: e.clientY, ox: pos.x, oy: pos.y };
    garment.setPointerCapture(e.pointerId);
  });
  garment.addEventListener('pointermove', (e) => {
    if (!drag) return;
    pos.x = Math.min(100, Math.max(0, drag.ox + ((e.clientX - drag.sx) / drag.r.width) * 100));
    pos.y = Math.min(100, Math.max(0, drag.oy + ((e.clientY - drag.sy) / drag.r.height) * 100));
    place();
  });
  const stop = () => { drag = null; };
  garment.addEventListener('pointerup', stop);
  garment.addEventListener('pointercancel', stop);
  garment.addEventListener('keydown', (e) => {
    const d = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
    if (!d) return;
    e.preventDefault();
    pos.x = Math.min(100, Math.max(0, pos.x + d[0]));
    pos.y = Math.min(100, Math.max(0, pos.y + d[1]));
    place();
  });

  // photo upload (stays in the browser)
  file.addEventListener('change', () => {
    const f = file.files && file.files[0];
    if (!f) return;
    if (!f.type.startsWith('image/')) {
      fileMsg.textContent = 'Choose an image file (JPG, PNG or WebP).';
      return;
    }
    if (photoUrl) URL.revokeObjectURL(photoUrl);
    photoUrl = URL.createObjectURL(f);
    photo.src = photoUrl;
    photo.hidden = false;
    stage.classList.add('has-photo');
    fileMsg.textContent = 'Photo loaded. Drag the garment into place.';
  });

  $('#tryAdd').addEventListener('click', () => {
    const brand = BRANDS.find((b) => b.id === sel.value) || BRANDS[0];
    const rec = recommend(brand, state.cat, state.m);
    onAdd({ brandId: brand.id, cat: state.cat, size: rec.size, color, photo: photoUrl });
  });

  garment.style.width = scale.value + '%';
  refresh();
  return { refresh };
}
